data(kidneytran)
library("survival")
#install.packages('BayHaz')
library(BayHaz)
#install.packages('bnlearn')
library(bnlearn)
library(ggplot2)
library(tidyr)


summary(kidneytran)

str(kidneytran)

kidneydata <- data(kidneydata)



kidneytran$delta <- as.numeric(kidneytran$delta)
kidneytran$gender <- as.numeric(kidneytran$gender)
kidneytran$race <- as.numeric(kidneytran$race)

str(kidneytran)

kidneytran$obs <- as.numeric(kidneytran$obs)
kidneytran$time <- as.numeric(kidneytran$time)
kidneytran$age <- as.numeric(kidneytran$age)
str(kidneytran)


# Distribution of Data 
kidneytran<- kidneytran[,-1]
str(kidneytran)

ggplot(data = kidneytran, aes(x = kidneytran$time, fill = kidneytran$delta)) + 
  geom_histogram() + 
  facet_grid(kidneytran$delta ~.) + 
  ggtitle("Distribution of time-to-event by type of treatment")

boxplot(kidneytran$age , kidneytran$delta)

ggplot(data = kidneytran, aes(x = kidneytran$age, fill = kidneytran$delta)) + 
  geom_histogram() + 
  ggtitle("Age")

ggplot(data = kidneytran, aes(x = kidneytran$gender, fill = kidneytran$delta)) + 
  geom_crossbar() + 
  ggtitle("Gender")

ggplot(data = kidneytran, aes(x = kidneytran$race, fill = kidneytran$delta)) + 
  geom_histogram() + 
  ggtitle("Age")

library(GGally)
ggpairs(kidneytran)
##############


#cols <- c(1, 2 ,6)
#v <- kidneytran[cols]

d<- discretize(kidneytran , method = 'quantile' , breaks = 6 )
plot(hc(d))

bn.d <- hc(kidneytran)
plot(hc(kidneytran))
bn.d <- bn.fit(bn.d,kidneytran)
coefficients(bn.d)
bn.fit.qqplot(bn.d)
bn.fit.barchart(bn.d)



############Discreet#################33

data1 <- kidneytran



data1$delta <- factor(data1$delta)
data1$gender <- factor(data1$gender)
data1$race <- factor(data1$race)

str(data1)

##Discreet
cols_n <- c(3:5)
h<- data1[cols_n]
#plot(hc(h))
bn.h <- hc(h)
bn.h <- bn.fit(bn.h,h)
coefficients(bn.h)
bn.fit.barchart(bn.h$gender)
bn.fit.barchart(bn.h$race)
bn.fit.barchart(bn.h$delta)

