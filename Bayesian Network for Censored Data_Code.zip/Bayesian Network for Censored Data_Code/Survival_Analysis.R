library(survival)
library(ranger)
library(ggplot2)
library(dplyr)
library(ggfortify)

#------------
head(kidneytran)

#-----------------------Kaplan Meier Survival Curve-------------------------------
km <- with(kidneytran, Surv(time, delta))
head(km,80)
# Overall survival probability
km_fit <- survfit(Surv(time, delta) ~ 1, data=kidneytran)
summary(km_fit, times = c(1,30,60,90*(1:10)))
#plot(km_fit, xlab="Days", main = 'Kaplan Meyer Plot')
overall <- autoplot(km_fit)
overall <- overall + ggtitle("Survival Analysis") +
  labs(x = "Time", y = "Survival Probability")
overall

# Factorize the discrete variables
kidneytran_mutated <- mutate(kidneytran, age = ifelse((age < 60), "LT60", "OV60"), 
                                        gender = ifelse((gender == 1), "Male", "Female"),
                                        race = ifelse((race == 1), "White", "Black"),
                                        
              age = factor(age),
              gender = factor(gender),
              race = factor(race))

#Age based Survival
km_AG_fit <- survfit(Surv(time, delta) ~ age, data=kidneytran_mutated)
ageplot <- autoplot(km_AG_fit)
ageplot <- ageplot + ggtitle("Age based Survival") +
  labs(x = "Time", y = "Survival Probability") +
  guides(fill=FALSE) +
  labs(colour = "Age") 
ageplot

#Gender based Survival
km_gender_fit <- survfit(Surv(time, delta) ~ gender, data=kidneytran_mutated)
genderplot <- autoplot(km_gender_fit)
genderplot <- genderplot + ggtitle("Gender based Survival") +
  labs(x = "Time", y = "Survival Probability") +
  guides(fill=FALSE) +
  labs(colour = "Gender")
genderplot

#Race based Survival
km_race_fit <- survfit(Surv(time, delta) ~ race, data=kidneytran_mutated)
raceplot <- autoplot(km_race_fit)
raceplot <- raceplot + ggtitle("Race based Survival") +
  labs(x = "Time", y = "Survival Probability") +
  guides(fill=FALSE) +
  labs(colour = "Race")
raceplot

#-----------------------Cox Proportional Model-------------------------------
# Fit Cox Model
cox <- coxph(Surv(time, delta) ~ age + gender + race , data = kidneytran_mutated)
summary(cox)
# Overall survival probability
cox_fit <- survfit(cox)
#plot(cox_fit, main = "cph model", xlab="Days")
cox_overall <- autoplot(cox_fit)
cox_overall <- cox_overall + ggtitle("Survival Probability") +
  labs(x = "Time", y = "Survival Probability")
cox_overall

# Survival probability for Predictors
aa_fit <-aareg(Surv(time, delta) ~ age + gender + race , 
               data = kidneytran_mutated)
aa_fit
#summary(aa_fit)  # provides a more complete summary of results
cox_predictors <- autoplot(aa_fit)
cox_predictors <- cox_predictors + ggtitle("Predictors") +
  labs(x = "Time", y = "Survival Probability")
cox_predictors