install.packages('BayesSurvival')
library(BayesSurvival)


bs1<- BayesSurv(
  kidneytran,
  time = "time",
  event = "delta",
  prior = c("Independent"),
  alpha = 0.05,
  N = 1000,
  alpha.dep = 1,
  alpha0.dep = 1.5,
  beta0.dep = 1,
  alpha.indep = 1.5,
  beta.indep = 1,
  surv.factor = 10,
  surv.epsilon = 1e-10
)

PlotBayesSurv(bs1, object = "survival" ,xlab = 'Time',ylab = 'Survival Probability', color = "lightblue" , plot.title ='Posterior Survival Distribution' , legend = TRUE  )


#PlotBayesSurv(bs1, object = "survival")
PlotBayesSurv(bs1, object = "cumhaz" ,)
PlotBayesSurv(bs1, object = "hazard")


